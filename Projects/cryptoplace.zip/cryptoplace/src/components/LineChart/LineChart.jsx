import React, { useState } from "react";
import Chart from "react-google-charts";

const LineChart = () => {
  const [data, setData] = useState([["Date", "Prices"]]);
  return <div></div>;
};

export default LineChart;
