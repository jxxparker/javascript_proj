const fs = require("fs");

const hello = "Hello world";
console.log(hello);
